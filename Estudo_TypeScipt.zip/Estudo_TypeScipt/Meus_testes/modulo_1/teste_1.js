"use strict";
console.log('==== Desafio 1! Transformando códigos Python em TypeScript ====');
let nombre = 'Miguel Ectil';
console.log('Olá', nombre, 'prazer em te conhecer!');
// ==> Data de nascimento
console.log('==== Desafio 2! ====');
let dia = 7;
let mes = 'março';
let ano = 2005;
console.log('Você nasceu no dia', dia, 'de', mes, 'de', ano);
