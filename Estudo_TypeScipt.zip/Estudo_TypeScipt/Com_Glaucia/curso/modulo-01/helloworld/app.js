"use strict";
let mensagem = 'Hello World, Miguel Ectil';
console.log(mensagem);
