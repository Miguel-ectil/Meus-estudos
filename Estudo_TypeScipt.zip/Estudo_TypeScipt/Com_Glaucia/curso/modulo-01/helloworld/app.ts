
let mensagem: string = 'Hello World, Miguel Ectil'
console.log(mensagem);