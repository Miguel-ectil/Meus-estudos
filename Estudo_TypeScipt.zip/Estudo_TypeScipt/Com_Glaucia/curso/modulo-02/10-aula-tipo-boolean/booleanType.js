"use strict";
// ==> Exemplo 01
let tarefaConcluida = true;
let tarefaPendente = false;
console.log(tarefaConcluida);
console.log(tarefaPendente);
console.log('================================');
// ==> Exemplo 02 
let concluido = false;
if (!concluido) {
    console.log('Tarefa foi concluida com sucesso');
}
else {
    console.log('Tarefa Pendente');
}
