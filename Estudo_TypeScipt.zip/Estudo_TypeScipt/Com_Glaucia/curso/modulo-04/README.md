# Módulo 4: Funções/Functions

Aqui vocês encontrarão todos os vídeos e os exemplos desenvolvidos durante o módulo 04.

## 💻 Série de Vídeos

| Vídeo Aula | Descrição |
|---|---|
| **[Vídeo 42](https://youtu.be/AU7-s7Ucock)** | Vídeo 42 - Intro à Funções  |
| **[Vídeo 43](https://youtu.be/DHTQwvXcZOs)** | Vídeo 43 - Demo: Funções  |
| **[Vídeo 44](https://youtu.be/faHgw09dcsw)** | Vídeo 44 - Optional Parameters |
| **[Vídeo 45](https://youtu.be/8lkQjfuif8c)** | Vídeo 45 - Demo: Optional Parameters |
| **[Vídeo 46](https://youtu.be/zbnwyJybtPg)** | Vídeo 46 - Default Parameters |
| **[Vídeo 47](https://youtu.be/RFyhBnowMOY)** | Vídeo 47 - Demo: Default Parameters  |
| **[Vídeo 48](https://youtu.be/GdxGQA8ppk0)** | Vídeo 48 - Rest Parameters |
| **[Vídeo 49](https://youtu.be/hEe0rD4-LVM)** | Vídeo 49 - Demo: Rest Parameters |
