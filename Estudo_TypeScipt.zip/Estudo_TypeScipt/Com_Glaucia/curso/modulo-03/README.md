# Módulo 3: Fluxos de Controle

Aqui vocês encontrarão todos os vídeos e os exemplos desenvolvidos durante o módulo 03.

## 💻 Série de Vídeos

| Vídeo Aula                                   | Descrição                      |
| -------------------------------------------- | ------------------------------ |
| **[Vídeo 34](https://youtu.be/sU9miGUUJrI)** | Vídeo 34 - If...else           |
| **[Vídeo 35](https://youtu.be/_KkjHVo4x_M)** | Vídeo 35 - Demo: If...else     |
| **[Vídeo 36](https://youtu.be/-rUHKfnbq7g)** | Vídeo 36 - Switch...case       |
| **[Vídeo 37](https://youtu.be/kaKlKebVqco)** | Vídeo 37 - Demo: Switch...case |
| **[Vídeo 38](https://youtu.be/KUi9FhBResg)** | Vídeo 38 - For                 |
| **[Vídeo 39](https://youtu.be/-yAy5hBuW20)** | Vídeo 39 - Demo: For           |
| **[Vídeo 40](https://youtu.be/01Hu8ekpnEc)** | Vídeo 40 - While/do...while    |
| **[Vídeo 41](https://youtu.be/h1BpPZyl8j8)** | Vídeo 41 - Demo: While/do...while |
