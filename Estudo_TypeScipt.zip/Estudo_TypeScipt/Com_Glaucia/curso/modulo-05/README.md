# Módulo 6: Enum     

Aqui vocês encontrarão todos os vídeos e os exemplos desenvolvidos durante o módulo 06.

## 💻 Série de Vídeos

| Vídeo Aula | Descrição |
|---|---|
| **[Vídeo 01]()** | Vídeo 01 -  |
| **[Vídeo 02]()** | Vídeo 02 -  |
| **[Vídeo 03]()** | Vídeo 03 -  |
| **[Vídeo 04]()** | Vídeo 04 -  |
| **[Vídeo 05]()** | Vídeo 05 -  |
| **[Vídeo 06]()** | Vídeo 06 -  |