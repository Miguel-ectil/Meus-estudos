class Produto {
    codigo: string;
    descricao: string;
    preco : n
}