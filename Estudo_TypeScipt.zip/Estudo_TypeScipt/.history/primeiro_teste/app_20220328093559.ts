class Produto {
    codigo: string;
}