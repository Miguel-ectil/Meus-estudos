class Produto {
    codigo
}