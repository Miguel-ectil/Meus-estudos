class Produto {
    codigo: string;
    descrip
}