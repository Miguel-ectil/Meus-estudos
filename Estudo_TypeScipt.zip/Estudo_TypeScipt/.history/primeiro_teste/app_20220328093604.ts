class Produto {
    codigo: string;
    descri
}