class Produto {
    codigo: string;
    descrica
}