class Produto {
    codigo: string;
    descriu
}