
console.log('====== Desfio 1! TRansformar código python em tyupe')