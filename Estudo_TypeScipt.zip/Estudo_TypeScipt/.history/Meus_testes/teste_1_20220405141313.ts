
console.log('====== Desfio 1! TRansformar código pytho')