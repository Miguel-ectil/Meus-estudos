
console.log('==== Desfio 1! TRansformar código Python em TypeScript ====');

let nombre: string = 'Miguel Ectil';

console.log('Olánombre, 'Ola prazer em te conhecer!')
