
console.log('==== Desfio 1! TRansformar código Python em TypeScript ====');

let no: string = 'Miguel Ectil';

console.log(name, 'Ola prazer em te conhecer!')
