
console.log('==== Desfio 1! TRansformar código Python em TypeScript ====');

let name: string = ''

console.log('Olá prazer em te conhecer!')
