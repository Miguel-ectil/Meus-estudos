
console.log('==== Desafio 1! Transformando códigos Python em TypeScript ====');

let nombre: string = 'Miguel Ectil';

console.log('Olá', nombre, 'prazer em te conhecer!');

// ==> Data de nascimento

console.log('==== Desafio 2! ====');

let carro: {
    nome: string;
    ano: number;
    preco: number;
};

carro = { nome: 'Toyota Yaris Sedan XS', ano: 2019, preco: 80000}
console.log(carro);