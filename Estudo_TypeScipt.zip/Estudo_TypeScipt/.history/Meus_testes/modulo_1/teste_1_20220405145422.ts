
console.log('==== Desafio 1! Transformando códigos Python em TypeScript ====');

let nombre: string = 'Miguel Ectil';

console.log('Olá', nombre, 'prazer em te conhecer!')

// ==> Data de nascimento

console.log('==== Desafio 2! ====')

let dia: number = '07'
let mes