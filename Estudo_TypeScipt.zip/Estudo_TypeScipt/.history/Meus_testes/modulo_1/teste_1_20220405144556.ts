
console.log('==== Desfio 1! TRansformar código Python em TypeScript ====');

let nombre: string = 'Miguel Ectil';

console.log('Olá',nombre, 'Ola prazer em te conhecer!')

console.log('')