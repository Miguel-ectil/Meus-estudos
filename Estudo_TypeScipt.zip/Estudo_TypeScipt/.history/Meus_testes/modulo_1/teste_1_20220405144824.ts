
console.log('==== Desafio 1! Transformando códigos Python em TypeScript ====');

let nombre: string = 'Miguel Ectil';

console.log('Olá',nombre, 'Ola prazer em te conhecer!')

console.log('====Desafio 1!')