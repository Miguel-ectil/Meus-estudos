
console.log('==== Desfio 1! TRansformar código Python em TypeScript ====')

let nome: string = 'Miguel';

console.log('Olá', nome, 'prazer em te conhecer!')