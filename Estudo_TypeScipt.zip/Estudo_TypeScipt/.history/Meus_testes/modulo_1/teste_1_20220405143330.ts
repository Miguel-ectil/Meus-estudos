
console.log('==== Desfio 1! TRansformar código Python em TypeScript ====');

let name: string = 'Migeu'

console.log('Olá prazer em te conhecer!')
