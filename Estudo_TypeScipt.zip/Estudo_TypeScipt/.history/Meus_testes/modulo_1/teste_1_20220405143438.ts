
console.log('==== Desfio 1! TRansformar código Python em TypeScript ====');

let name: string = 'Miguel Ectil';

console.log('Ola' name: 'Miguel Ectilprazer em te conhecer!')
