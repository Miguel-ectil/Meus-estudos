
console.log('==== Desafio 1! Transformando códigos Python em TypeScript ====');

let nombre: string = 'Miguel Ectil';

console.log('Olá', nombre, 'prazer em te conhecer!')

console.log('==== Desafio 2! ====')

let dia: number = ''