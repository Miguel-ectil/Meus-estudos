
console.log('==== Desfio 1! TRansformar código Python em TypeScript ====')

let nome